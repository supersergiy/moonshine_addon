sudo apt-get undate
sudo apt-get update
sudo apt-get upgrage
sudo apt-get upgrade
sudo apt-get install autotools-dev
sudo apt-get install pkg-config
sudo apt-get install doxygen
sudo apt-get install gettext
sudo apt-get install libz
sudo apt-get install zlib
sudo apt-get install libz-dev
sudo apt-get install libz-liblzma
sudo apt-get install liblzma
sudo apt-get install liblzma-dev
sudo apt-get install libbz2
sudo apt-get install bzip2
sudo apt-get install libgnutls
sudo apt-get install libgnutls-dev
sudo apt-get install libidn2
sudo apt-get install libidn2-dev
sudo apt-get install libidn
sudo apt-get install libidn-dev
sudo apt-get install libunistring
sudo apt-get install libunistring-dev
sudo apt-get install libidn2-0-dev
sudo apt-get install flex
sudo apt-get install libpsl
sudo apt-get install libpsl-dev
sudo apt-get install libnghttp2
sudo apt-get install libnghttp2-dev